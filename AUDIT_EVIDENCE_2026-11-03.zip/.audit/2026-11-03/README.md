# Audit evidence — 3 November 2026

See [the architecture audit](../../ARCHITECTURE_AUDIT.md) for findings and limitations.

This directory is excluded from automatic source scanning through `.audit/.gitignore`. Its contents are preserved in `AUDIT_EVIDENCE_2026-11-03.zip` at the project root; extract that archive into the project root to restore the same evidence paths. The final build returned the original application asset hashes after excluding diagnostic snippets from scanning.

| File | Evidence |
| --- | --- |
| `lighthouse-mobile.json` | Incognito DevTools Lighthouse 13.5.0 mobile-preset run. Simulated Slow 4G/4× CPU; IndexedDB warning and screen-emulation configuration caveat retained. |
| `npm-audit.json` | npm registry advisory response for the frontend lockfile: 13 affected package entries. |
| `frontend-build.log` | Successful Vite production build and bundle-size warning. |
| `frontend-typecheck.log` | Failed TypeScript check: 685 diagnostics, mostly cascading missing declaration errors. |
| `backend-tests.log` | Nine existing backend tests pass. These use isolated stores and in-process HTTP mocks. |
| `backend-typecheck.log` | Six backend TypeScript diagnostics using matching shared installed tooling. |
| `backend-probes.mjs` | Additional controlled assertions against a supplied backend checkout; no real Firestore calls. |
| `backend-probes.log` | All 17 assertions completed, including reproduced weaknesses and two passing controls. |

Backend source revision tested: `9d05ea7e10c97448ebaa22f30f957d9c63e240c2` from `Snap-of-Love/S.O.L_Back_End`. Temporary checkout used during this audit: `/private/tmp/sol-backend-audit`.

Run the additional probes with Node supporting TypeScript type stripping (Node 26.0.0 was used):

```sh
node .audit/2026-11-03/backend-probes.mjs /path/to/S.O.L_Back_End
```

The probes intentionally assert the vulnerable behavior in the audited revision. A completed probe is evidence of that behavior, not a security pass. They run in a separate process, use fake test secrets, force isolated test storage, and replace global fetch with local responses during persistence checks. After remediation, convert them to safe-behavior regression tests.

Other checks:

```sh
npm ci --ignore-scripts
npm run lint
npm run build
npm audit --json
npm run preview -- --host 127.0.0.1 --port 4173
```

From the backend checkout, run `npm test` and `npm run lint`. The backend supplies no lockfile; the audit reused the frontend's installed toolchain rather than claiming an independently locked backend install.

Manual observations: desktop entrance rendered; Tab focused background controls behind the launch overlay; clicking the launch prompt produced a live INP observation of 240 ms; entering the studio and denying camera access left Start Session disabled; iPhone SE 375×667 layout was inspected; `/share` without an ID displayed its missing-reference error. Capture, export and real cloud sharing were not completed because no camera-approved fixture or staging services were supplied.

The local live LCP displayed after viewport changes is deliberately excluded from the audit's headline measurements. No production load, actual payment mutation, or personal photo upload was performed.
