import assert from 'node:assert/strict';
import { Readable } from 'node:stream';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
if (!process.argv[2]) throw new Error('Usage: node backend-probes.mjs /path/to/S.O.L_Back_End');
const backendRoot = resolve(process.argv[2]);
const backendModule = path => import(pathToFileURL(resolve(backendRoot, path)).href);
process.env.NODE_ENV = 'test';
const { createRequestHandler } = await backendModule('src/app.ts');
const { createCollectionStore } = await backendModule('src/config/firebase.ts');
const { loadEnvConfig } = await backendModule('src/config/env.ts');
const config = {port:4000,nodeEnv:'test',allowedOrigins:['https://allowed.example'],apiSecretKey:'audit-only-secret',webhookSecret:'audit-only-webhook',geminiApiKey:null,maxPayloadBytes:1048576,rateLimitWindowMs:60000,rateLimitMaxWriteRequests:1,sessionTtlSeconds:900};
async function invoke(handler, method, url, body, headers={}) {
  const req=Object.assign(Readable.from(body===undefined?[]:[Buffer.from(JSON.stringify(body))]),{method,url,headers:{host:'localhost',...headers},socket:{remoteAddress:'127.0.0.1'}});
  let status=200, output='';const responseHeaders={};
  const res={headersSent:false,setHeader(k,v){responseHeaders[k.toLowerCase()]=String(v)},writeHead(s,h={}){status=s;this.headersSent=true;for(const[k,v]of Object.entries(h))responseHeaders[k.toLowerCase()]=String(v)},end(s=''){output+=s},write(s){output+=s}};
  await handler(req,res); return {status,headers:responseHeaders,body:output,json:()=>JSON.parse(output)};
}
const observations=[];
async function probe(name,run){await run();observations.push({name,result:'reproduced'});console.log('REPRODUCED:',name)}
const handler=createRequestHandler({config});
const payload={imageUrl:'data:image/jpeg;base64,/9j/4AAQSkZJRg==',layout:'1x4',format:'jpg'};
const sessionA=(await invoke(handler,'POST','/v1/sessions')).json();
const sessionB=(await invoke(handler,'POST','/v1/sessions')).json();
const authA={authorization:`Bearer ${sessionA.token}`};
const authB={authorization:`Bearer ${sessionB.token}`};
const created=(await invoke(handler,'POST','/v1/shares',payload,authA)).json();
await probe('Anonymous no-Origin session B lists session A share',async()=>{const r=await invoke(handler,'GET','/v1/shares',undefined,authB);assert.equal(r.status,200);assert.ok(r.json().data.some(x=>x.id===created.id));});
await probe('Anonymous session B deletes session A share',async()=>{assert.equal((await invoke(handler,'DELETE',`/v1/shares/${created.id}`,undefined,authB)).status,204)});
await probe('CORS denies unauthorized Origin and allows configured Origin',async()=>{assert.equal((await invoke(handler,'POST','/v1/sessions',undefined,{origin:'https://evil.example'})).status,403);assert.equal((await invoke(handler,'POST','/v1/sessions',undefined,{origin:'https://allowed.example'})).headers['access-control-allow-origin'],'https://allowed.example')});
const transaction=(await invoke(handler,'POST','/v1/transactions',{amount:100,status:'completed'},authA)).json();
await probe('Anonymous session can create already-completed transaction',async()=>{assert.equal(transaction.status,'completed')});
await probe('Unauthenticated transaction detail read exposes record',async()=>{const r=await invoke(handler,'GET',`/v1/transactions/${transaction.id}`);assert.equal(r.status,200);assert.equal(r.json().amount,100)});
await probe('Anonymous session B lists all transactions',async()=>{assert.equal((await invoke(handler,'GET','/v1/transactions',undefined,authB)).json().data[0].id,transaction.id)});
await probe('Missing webhook secret permits unsigned payment status update',async()=>{const h=createRequestHandler({config:{...config,webhookSecret:null}});const t=(await invoke(h,'POST','/v1/transactions',{amount:100},authA)).json();assert.equal((await invoke(h,'POST','/v1/transactions/webhook',{transactionId:t.id,status:'completed'})).status,200)});
await probe('X-Forwarded-For rotation bypasses single-IP write limit',async()=>{const h=createRequestHandler({config});assert.equal((await invoke(h,'POST','/v1/shares',payload,{...authA,'x-forwarded-for':'198.51.100.1'})).status,201);assert.equal((await invoke(h,'POST','/v1/shares',payload,{...authA,'x-forwarded-for':'198.51.100.1'})).status,429);assert.equal((await invoke(h,'POST','/v1/shares',payload,{...authA,'x-forwarded-for':'198.51.100.2'})).status,201)});
await probe('Caption endpoint accepts repeated unauthenticated calls beyond write limit',async()=>{for(let i=0;i<3;i++)assert.equal((await invoke(handler,'POST','/v1/shares/caption',{mood:'minimal'})).status,200)});
await probe('Malformed request URL rejects outside safe error boundary',async()=>{await assert.rejects(()=>invoke(handler,'GET','http://['))});
await probe('Internal service failure produces generic 500 without stack or secret',async()=>{const h=createRequestHandler({config,sharesService:{getShareById:async()=>{throw new Error('audit-secret-internal-stack')}}});const r=await invoke(h,'GET','/v1/shares/demo');assert.equal(r.status,500);assert.ok(!r.body.includes('audit-secret'));assert.equal(r.json().request_id.length>0,true)});
await probe('Production configuration accepts missing API and webhook secrets',async()=>{process.env.NODE_ENV='production';delete process.env.API_SECRET_KEY;delete process.env.WEBHOOK_SECRET;const c=loadEnvConfig();assert.equal(c.apiSecretKey,null);assert.equal(c.webhookSecret,null)});
const realFetch=globalThis.fetch;process.env.FIREBASE_API_KEY='audit-placeholder-not-real';process.env.FIREBASE_PROJECT_ID='audit-local-only';
try {
  const record={id:'audit-record',createdAt:'2026-11-03T00:00:00Z',status:'pending'};
  await probe('Firestore 403 create is reported as success and stored only in memory',async()=>{globalThis.fetch=async()=>new Response('{}',{status:403});const s=createCollectionStore('transactions');assert.deepEqual(await s.create(record.id,record),record);assert.deepEqual(await s.getById(record.id),record)});
  await probe('Transaction update never sends a database request',async()=>{let calls=0;globalThis.fetch=async()=>{calls++;return new Response('{}',{status:200})};const s=createCollectionStore('transactions');await s.create(record.id,record);calls=0;assert.equal((await s.update(record.id,{status:'completed'})).status,'completed');assert.equal(calls,0)});
  await probe('Database delete denied with 403 is still reported as successful',async()=>{globalThis.fetch=async()=>new Response('{}',{status:403});const s=createCollectionStore('transactions');await s.create(record.id,record);assert.equal(await s.deleteById(record.id),true)});
  await probe('Cursor page skips Firestore and returns empty local memory',async()=>{let calls=0;globalThis.fetch=async()=>{calls++;return new Response('[]',{status:200})};const s=createCollectionStore('shares');assert.equal((await s.list(20,'database-only-record')).items.length,0);assert.equal(calls,0)});
}finally{globalThis.fetch=realFetch;process.env.NODE_ENV='test';delete process.env.FIREBASE_API_KEY;delete process.env.FIREBASE_PROJECT_ID;}
await probe('Concurrent identical Idempotency-Key requests create two share IDs',async()=>{const h=createRequestHandler({config:{...config,rateLimitMaxWriteRequests:30}});const headers={...authA,'idempotency-key':'audit-concurrent-key'};const [a,b]=await Promise.all([invoke(h,'POST','/v1/shares',payload,headers),invoke(h,'POST','/v1/shares',payload,headers)]);assert.equal(a.status,201);assert.equal(b.status,201);assert.notEqual(a.json().id,b.json().id)});
console.log(JSON.stringify({count:observations.length,observations},null,2));
